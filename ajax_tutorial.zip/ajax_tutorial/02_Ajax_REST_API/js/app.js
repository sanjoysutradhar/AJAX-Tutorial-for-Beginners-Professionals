import {BrainHttp} from "../api/brainHttp.js";
const serverUrl=`http://127.0.0.1:3000/api`;
//GET Button
// let getButton= document.querySelector('#get-btn');
let getButton= document.getElementById('get-btn')
getButton.addEventListener('click', function(){
    fetchEmployees();
});

// let fetchEmployees=()=>{
//     let http=new BrainHttp();
//     let url = `${serverUrl}/employees`
//     http.get(url,(err, employees)=>{
//         if(err) throw err;
//         // console.log(employees);
//         let tableRows='';
//         for(let employee of employees){
//             tableRows+=`<tr>
//                             <td>${employee.id}</td>
//                             <td>${employee.first_name}</td>
//                             <td>${employee.last_name}</td>
//                             <td>${employee.email}</td>
//                             <td>${employee.gender}</td>
//                             <td>${employee.ip_address}</td>
//                         </tr>`
//         }
//         document.getElementById('table-body').innerHTML=tableRows;
//     });
// }

let fetchEmployees=()=> {
    let url = `${serverUrl}/employees`
    $.ajax({
        type: 'GET',
        url: url,
        success: function (response) {
            // console.log(response)
            let tableRows='';
            for(let employee of response){
                tableRows+=`<tr>
                                <td>${employee.id}</td>
                                <td>${employee.first_name}</td>
                                <td>${employee.last_name}</td>
                                <td>${employee.email}</td>
                                <td>${employee.gender}</td>
                                <td>${employee.ip_address}</td>
                            </tr>`
            }
            document.getElementById('table-body').innerHTML=tableRows;
        },
        error: function (err) {
            console.log(err);
        }
    });
}

//post button

let postButton=document.getElementById('post-btn');
postButton.addEventListener('click',function(){
    postEmployee();
});

let postEmployee=()=>{
    let url = `${serverUrl}/employees`;
    $.ajax({
        type:'post',
        url:url,
        data:{
          first_name:'Rajon',
          last_name:'Jain',
          email:'rajon@gmail.com',
          gender:'male',
          ip_address:'127.0.0.5'
        },
        success:function(response){
            console.log(response);
            fetchEmployees();
        },
        error:function(err){
            console.log(err);
        }
    });
}

// put button

let putButton = document.getElementById('put-btn');
putButton.addEventListener('click',function(){
    let empId = `_abcdf`;
    let url = `${serverUrl}/employees/${empId}`;
    let employee ={
        first_name:'Laura',
        last_name:'Wilson',
        email:'wilson@gmail.com',
        gender:'Female',
        ip_address:'127.0.3.2',
    }
    $.ajax({
       type:'PUT',
       url:url,
       // data:{
       //     id: empId,
       //     first_name:'Laura',
       //     last_name:'Wilson',
       //     email:'wilson@gmail.com',
       //     gender:'Female',
       //     ip_address:'127.0.3.2',
       // },
        data: employee,
        dataType: "json",
        // contentType: "application/json;charset=utf-8",
       success:function(data, textStatus, xhr){
           console.log(data,textStatus,xhr);
           fetchEmployees();
       },
       error:function(err){
           console.log(err)
       }
    });
})


// delete button

let deleteBtn=document.getElementById('delete-btn');

deleteBtn.addEventListener('click',function(){
    let empId = `_abcdf`;
    let url = `${serverUrl}/employees/${empId}`;
    $.ajax({
        type:'delete',
        url:url,
        success:function (data) {
            console.log(data);
            fetchEmployees();
        }
    });
});