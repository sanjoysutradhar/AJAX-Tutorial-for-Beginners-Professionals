export class BrainHttp{
    constructor() {
        this.http= new XMLHttpRequest();
    }

    // get request

    get=(url, callback)=>{
        this.http.open('GET',url, true);
        this.http.send();
        this.onload=()=>{
            if(this.http.status===200){
                let data= this.http.responseText;
                let employees= JSON.parse(data);
                callback(employees);
                // console.log(data);
            }else{
                callback(`Error: ${this.http.status}`);
            }
        }
    }


    // get=(url)=>{
    //     $.ajax({
    //         type:'GET',
    //         url:url,
    //         success:function(response){
    //             return response
    //             // console.log(response)
    //         },
    //         error:function(err){
    //             console.log(err);
    //         }
    //     });
    // }
}