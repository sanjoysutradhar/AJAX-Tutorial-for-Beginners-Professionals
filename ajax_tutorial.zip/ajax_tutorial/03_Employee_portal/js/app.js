import {BrainHttp} from "../api/brainHttp.js";
const serverUrl=`http://127.0.0.1:3000/api`;
// DOM Content Loaded
window.addEventListener('DOMContentLoaded',(event)=>{
    fetchEmployees();
});

// let fetchEmployees=()=>{
//     let http=new BrainHttp();
//     let url = `${serverUrl}/employees`
//     http.get(url,(err, employees)=>{
//         if(err) throw err;
//         // console.log(employees);
//         let tableRows='';
//         for(let employee of employees){
//             tableRows+=`<tr>
//                             <td>${employee.id}</td>
//                             <td>${employee.first_name}</td>
//                             <td>${employee.last_name}</td>
//                             <td>${employee.email}</td>
//                             <td>${employee.gender}</td>
//                             <td>${employee.ip_address}</td>
//                         </tr>`
//         }
//         document.getElementById('table-body').innerHTML=tableRows;
//     });
// }

let fetchEmployees=()=> {
    let url = `${serverUrl}/employees`
    $.ajax({
        type: 'GET',
        url: url,
        success: function (response) {
            console.log(response)
            let tableRows='';
            for(let employee of response){
                tableRows+=`<tr>
                                <td>${employee.id}</td>
                                <td>${employee.first_name}</td>
                                <td>${employee.last_name}</td>
                                <td>${employee.email}</td>
                                <td>${employee.gender}</td>
                                <td>${employee.ip_address}</td>
                                <td>
                                    <button class="btn btn-sm btn-secondary update">Update</button>
                                    <button class="btn btn-sm btn-danger delete">Delete</button>
                                </td>
                            </tr>`
            }
            document.getElementById('table-body').innerHTML=tableRows;
        },
        error: function (err) {
            console.log(err);
        }
    });
}

// Add Employee Form
// $('#add-employee-form').submit(function () {
//     alert();
// });

// $(document).on('submit','#add-employee-form',function(){
//     alert();
// })

let addEmployeeForm= document.getElementById('add-employee-form');
addEmployeeForm.addEventListener('submit',function(e){
    e.preventDefault(); //stop auto form submits
    $('#add-employee-modal').modal('hide'); // to close the modal
    // let first_name=document.querySelector('#first_name').value;
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.checked) {
            gender=radio.value;
        }
    }
    // alert(gender);
    let employee={
        first_name:document.querySelector('#first_name').value,
        last_name:document.querySelector('#last_name').value,
        email:document.querySelector('#email').value,
        gender:gender,
        ip_address:document.getElementById('ip_address').value,
    }
    let url = `${serverUrl}/employees`;
    $.ajax({
        type:"post",
        url:url,
        data:employee,
        success:function(response){
            console.log();
            fetchEmployees();
            clearFormFields();
        }
    });
});
//clear modal data
let clearFormFields=()=>{
    document.querySelector('#first_name').value='';
    document.querySelector('#last_name').value='';
    document.querySelector('#email').value='';
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.checked) {
            radio.checked=false;
        }
    }
    document.getElementById('ip_address').value='';
}

//Click Event on entire table body

let tableBody= document.getElementById('table-body');
tableBody.addEventListener("click", function (e) {
    let targetElement=e.target;
    // console.log(targetElement);
    if(targetElement.classList.contains('delete')){
        let selectedId= targetElement.parentElement.parentElement.firstElementChild.innerHTML;
        let url=`${serverUrl}/employees/${selectedId}`;
        $.ajax({
           type:'delete',
           url:url,
           success:function(response){
               console.log(response)
               fetchEmployees();
           }
        });
        console.log(selectedId);
        console.log('You clicked delete button');
    }
    if(targetElement.classList.contains('update')){
        let selectedId= targetElement.parentElement.parentElement.firstElementChild.innerHTML;
        // let url=`${serverUrl}/employees/${selectedId}`;
        let url=`${serverUrl}/employees`;
        $.ajax({
            type:'get',
            url:url,
            success:function(employees){
                let selectEmployee=employees.find((employee)=>{
                    return employee.id===selectedId.trim();
                });
                populateUpdateModal(selectEmployee);
                console.log(selectEmployee);
            }
        });
    }
});

let populateUpdateModal=(employee)=>{
    document.getElementById('update_id').value=employee.id;
    document.getElementById('update_first_name').value=employee.first_name;
    document.getElementById('update_last_name').value=employee.last_name
    document.getElementById('update_email').value=employee.email;
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.value===employee.gender) {
            radio.checked=true;
        }
    }
    document.getElementById('update_ip_address').value=employee.ip_address;
    $('#update-employee-modal').modal('show'); // to close the modal
}

let updateEmployeeForm= document.getElementById('update-employee-form');
updateEmployeeForm.addEventListener('submit',function(e){
    e.preventDefault(); //stop auto form submits
    $('#update-employee-modal').modal('hide'); // to close the modal
    let empId=document.getElementById('update_id').value;
    // alert(empId);
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.checked) {
            gender=radio.value;
        }
    }
    // alert(gender);
    let employee={
        id:empId,
        first_name:document.querySelector('#update_first_name').value,
        last_name:document.querySelector('#update_last_name').value,
        email:document.querySelector('#update_email').value,
        gender:gender,
        ip_address:document.getElementById('update_ip_address').value,
    }
    let url = `${serverUrl}/employees/${empId}`;
    $.ajax({
        type:"PUT",
        url:url,
        data: employee,
        // dataType: "json",
        success:function(response){
            // console.log(response);
            fetchEmployees();
            clearFormFields();
        }
    });
});