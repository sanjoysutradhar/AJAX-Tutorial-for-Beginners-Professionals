const express=require('express');
const app = express();
const bodyParser = require('body-parser');
const cors=require('cors');

const hostname="127.0.0.1";
const port =3000;

// create application/json parser
var jsonParser = bodyParser.json()

// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.use(jsonParser);
app.use(urlencodedParser);

//configure cors
app.use(cors());

const apiRouter =require('./api/apiRouter');

//configure the api router

app.use('/api',apiRouter);

// get
app.get('/',(request,response)=>{
    response.send(`<h2>Welcome to Express Server of Employee Portal</h2>`);
});

// app.get('/', (req, res)=>{
//     res.status(200);
//     res.send("Welcome to root URL of Server");
// });

app.listen(port, hostname,()=>{
    console.log(`Express Server is stared at http://${hostname}:${port}`);
})


// app.listen(port,hostname, (error) =>{
//     if(!error)
//         console.log(`Server is Successfully Running,and is stared at http://${hostname}:${port}`)
//     else
//         console.log("Error occurred, server can't start", error);
//     }
// );