const express=require('express');
const router =express.Router();

//employees data
let employees = [
    {
        id:'_fdsfh',
        first_name:'Jhon',
        last_name:'Wilson',
        email:'jhon@gmail.com',
        gender:'male',
        ip_address:'127.0.0.1',
    },
    {
        id:'_abcdf',
        first_name:'Laura',
        last_name:'Wilson',
        email:'laura@gmail.com',
        gender:'female',
        ip_address:'127.0.0.2',
    }
]

// get id
let getId = ()=>{
    return "_" + Math.random().toString(16).substr(2,9)
}

//Get - employees

router.get('/employees',(request,response)=>{
    console.log(`Get request received at server..${new Date().toLocaleTimeString()}`);
    response.json(employees);
});

router.post('/employees',(request,response)=>{
    // console.log(request);
    let employee={
        id:getId(),
        first_name:request.body.first_name,
        last_name:request.body.last_name,
        email:request.body.email,
        gender:request.body.gender,
        ip_address:request.body.ip_address,
    }
    employees.push(employee);

    console.log(`Post request received at server..${new Date().toLocaleTimeString()}`);
    response.json({msg:'post request is success'})
});

//put request
router.put('/employees/:id',(request,response)=>{
    let empId=request.params.id;
    let updateEmployee={
        id:empId,
        first_name:request.body.first_name,
        last_name:request.body.last_name,
        email:request.body.email,
        gender:request.body.gender,
        ip_address:request.body.ip_address,
    };
    let existingEmployee=employees.find((employee)=>{
       return employee.id===empId;
    });
    employees.splice(employees.indexOf(existingEmployee),1,updateEmployee);
    console.log(`Put request received at server..${new Date().toLocaleTimeString()}`);
    response.json({msg:'put request is success'});
});

router.delete('/employees/:id',(request,response)=>{
    let empId=request.params.id;
    employees=employees.filter((employee)=>{
        return employee.id !== empId;
    });
    console.log(`Delete request received at server..${new Date().toLocaleTimeString()}`);
    // response.json({msg:employees});
    response.json({msg:'Delete request is success'});
});

module.exports = router;
