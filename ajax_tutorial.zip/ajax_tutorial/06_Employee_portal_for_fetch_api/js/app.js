import {BrainHttp} from "../api/brainHttp.js";
const serverUrl=`http://127.0.0.1:3000/api`;
// DOM Content Loaded
window.addEventListener('DOMContentLoaded',(event)=>{
    fetchEmployees();
});

let fetchEmployees=()=> {
    let url = `${serverUrl}/employees`
    BrainHttp.get(url).then((data)=>{
        let employees= data;
        // console.log(data);
        let employeeRows='';
        for(let employee of employees){
            employeeRows+=`<tr>
                            <td>${employee.id}</td>
                            <td>${employee.first_name}</td>
                            <td>${employee.last_name}</td>
                            <td>${employee.email}</td>
                            <td>${employee.gender}</td>
                            <td>${employee.ip_address}</td>
                            <td>
                                <button class="btn btn-sm btn-secondary update">Update</button>
                                <button class="btn btn-sm btn-danger delete">Delete</button>
                            </td>
                        </tr>`
        }
        document.getElementById('table-body').innerHTML=employeeRows;
    }).catch((err)=>{
        console.log(err);
    });
}

// Add Employee Form
// $('#add-employee-form').submit(function () {
//     alert();
// });

// $(document).on('submit','#add-employee-form',function(){
//     alert();
// })

let addEmployeeForm= document.getElementById('add-employee-form');
addEmployeeForm.addEventListener('submit',function(e){
    e.preventDefault(); //stop auto form submits
    $('#add-employee-modal').modal('hide'); // to close the modal
    // let first_name=document.querySelector('#first_name').value;
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.checked) {
            gender=radio.value;
        }
    }
    // alert(gender);
    let employee={
        first_name:document.querySelector('#first_name').value,
        last_name:document.querySelector('#last_name').value,
        email:document.querySelector('#email').value,
        gender:gender,
        ip_address:document.getElementById('ip_address').value,
    }
    let url = `${serverUrl}/employees`;
    BrainHttp.post(url,employee).then((data)=>{
        console.log(data);
        fetchEmployees();
        clearFormFields();
    }).catch((err)=>{
        console.log(err);
    });
});
//clear modal data
let clearFormFields=()=>{
    document.querySelector('#first_name').value='';
    document.querySelector('#last_name').value='';
    document.querySelector('#email').value='';
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.checked) {
            radio.checked=false;
        }
    }
    document.getElementById('ip_address').value='';
}

//Click Event on entire table body

let tableBody= document.getElementById('table-body');
tableBody.addEventListener("click", function (e) {
    let targetElement=e.target;
    // console.log(targetElement);
    if(targetElement.classList.contains('delete')){
        let selectedId= targetElement.parentElement.parentElement.firstElementChild.innerHTML;
        let url=`${serverUrl}/employees/${selectedId}`;
        BrainHttp.delete(url).then(()=>{
            fetchEmployees();
        }).catch((err)=>{
            console.log(err);
        });
    }
    if(targetElement.classList.contains('update')){
        let selectedId= targetElement.parentElement.parentElement.firstElementChild.innerHTML;
        // let url=`${serverUrl}/employees/${selectedId}`;
        let url=`${serverUrl}/employees`;
        BrainHttp.get(url).then((employees)=>{
            let selectEmployee=employees.find((employee)=>{
                return employee.id===selectedId.trim();
            });
            populateUpdateModal(selectEmployee);
            console.log(selectEmployee);
        }).catch((err)=>{
            console.log(err);
        })
    }
});

let populateUpdateModal=(employee)=>{
    document.getElementById('update_id').value=employee.id;
    document.getElementById('update_first_name').value=employee.first_name;
    document.getElementById('update_last_name').value=employee.last_name
    document.getElementById('update_email').value=employee.email;
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.value===employee.gender) {
            radio.checked=true;
        }
    }
    document.getElementById('update_ip_address').value=employee.ip_address;
    $('#update-employee-modal').modal('show'); // to close the modal
}

let updateEmployeeForm= document.getElementById('update-employee-form');
updateEmployeeForm.addEventListener('submit',function(e){
    e.preventDefault(); //stop auto form submits
    $('#update-employee-modal').modal('hide'); // to close the modal
    let empId=document.getElementById('update_id').value;
    // alert(empId);
    let gender=document.getElementsByName('gender');
    for (var radio of gender){
        if (radio.checked) {
            gender=radio.value;
        }
    }
    // alert(gender);
    let employee={
        id:empId,
        first_name:document.querySelector('#update_first_name').value,
        last_name:document.querySelector('#update_last_name').value,
        email:document.querySelector('#update_email').value,
        gender:gender,
        ip_address:document.getElementById('update_ip_address').value,
    }
    let url = `${serverUrl}/employees/${empId}`;
    BrainHttp.put(url,employee).then((data)=>{
        fetchEmployees();
        clearFormFields();
    }).catch((err)=>{
        console.log(err);
    });
});