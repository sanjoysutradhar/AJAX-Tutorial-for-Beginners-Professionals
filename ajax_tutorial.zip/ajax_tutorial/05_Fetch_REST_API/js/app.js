import {BrainHttp} from "../api/brainHttp.js";
const serverUrl=`http://127.0.0.1:3000/api`;
//GET Button
// let getButton= document.querySelector('#get-btn');
let getButton= document.getElementById('get-btn')
getButton.addEventListener('click', function(){
   fetchEmployees();
});
// Fetch Employees
let fetchEmployees=()=>{
    let url=`${serverUrl}/employees`
    BrainHttp.get(url).then((data)=>{
        let employees= data;
        // console.log(data);
        let employeeRows='';
        for(let employee of employees){
            employeeRows+=`<tr>
                            <td>${employee.id}</td>
                            <td>${employee.first_name}</td>
                            <td>${employee.last_name}</td>
                            <td>${employee.email}</td>
                            <td>${employee.gender}</td>
                            <td>${employee.ip_address}</td>
                        </tr>`
        }
        document.getElementById('table-body').innerHTML=employeeRows;
    }).catch((err)=>{
        console.log(err);
    });
};

// post button

$(document).on('click','#post-btn',function(){
    let url=`${serverUrl}/employees`;
    let employee={
        first_name:'Rajon',
        last_name:'Jain',
        email:'rajon@gmail.com',
        gender:'male',
        ip_address:'127.0.0.5'
    }
    BrainHttp.post(url,employee).then((data)=>{
        console.log(data);
        fetchEmployees();
    }).catch((err)=>{
       console.log(err)
    });
});


//put button
$(document).on('click','#put-btn',function(){
    let empId = `_abcdf`;
    let url = `${serverUrl}/employees/${empId}`;
    let employee ={
        first_name:'Laura',
        last_name:'Wilson',
        email:'wilsonLaura@gmail.com',
        gender:'Male',
        ip_address:'127.0.3.2',
    }
    BrainHttp.put(url,employee).then((data)=>{
        // console.log(data);
        fetchEmployees();
    }).catch((err)=>{
        console.log(err)
    });
});

// delete btn
// document.getElementById('delete-btn');

$(document).on('click','#delete-btn',function(){
    let empId=`_abcdf`;
    let url = `${serverUrl}/employees/${empId}`;
    BrainHttp.delete(url).then((data)=>{
        console.log(data);
        fetchEmployees();
    }).catch((err)=>{
        console.log(err);
    });

});