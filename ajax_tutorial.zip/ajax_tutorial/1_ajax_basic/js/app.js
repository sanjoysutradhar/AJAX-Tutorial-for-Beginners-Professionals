let txtButton= document.querySelector('#text-btn');
// let txtButton= document.getElementById('text-btn')
txtButton.addEventListener('click', function(){
    //create an Ajax request
     let xhr= new XMLHttpRequest();
     // prepare the request
    xhr.open('GET','./data/message.txt', true);

    //send request
    xhr.send();

    //Process the Request

    // 1st way::
    xhr.onload=()=>{
        if(xhr.status===200){
            let data=xhr.responseText;
            console.log(data);
            displayTextData(data);
        }
    }

    // 2nd way::
    // xhr.onload=function(){
    //     if(xhr.status===200){
    //         let data=xhr.responseText;
    //         console.log(data);
    //     }
    // }

    // 3rd way::
    // xhr.onreadystatechange = function() {
    //     if (this.readyState == 4 && this.status == 200) {
    //         var response = xhr.responseText;
    //         console.log(response);
    //         // Process the server's response
    //     }
    // };

    // 4th way::
    // $.ajax({
    //     url:'./data/message.txt',
    //     type:'GET',
    //     success:function(response){
    //         console.log(response);
    //     }
    // });

    //display text data
    function displayTextData(data){
        let htmlTemplate= `<h4 class="text-uppercase">${data}</h4>`;

        // document.querySelector('#text-data-card').innerHTML=htmlTemplate;;
        // or
        document.getElementById('text-data-card').innerHTML=htmlTemplate;

    }
});


//Json Button

let jsonBtn=document.getElementById('json-btn');

jsonBtn.addEventListener('click',function () {
    // create an Ajax Request
    xhr=new XMLHttpRequest();

    // prepare the request
    xhr.open('get','./data/mobile.json',true);

    // request send
    xhr.send();

    // process the request
    xhr.onload=function(){
        if(xhr.status===200){
            let data=xhr.responseText;
            console.log(data);
            let mobile=JSON.parse(data);
            for(let key in mobile){
                // console.log(mobile[key]['id'])
                // for(let key1 in mobile[key]){
                //     htmlTemplate=`<ul class="list-group mt-3">
                //                       <li class="list-group-item">ID: ${mobile[key][key1]['id']}</li>
                //                       <li class="list-group-item">Brand: ${mobile[key][key1]['brand']}</li>
                //                       <li class="list-group-item">color: ${mobile[key][key1]['color']}</li>
                //                       <li class="list-group-item">price: ${mobile[key][key1]['Price']}</li>
                //                  </ul>`
                //     $('#json-data-card').append(htmlTemplate);
                // }
                htmlTemplate=`<ul class="list-group mt-3">
                                  <li class="list-group-item">ID: ${mobile[key]['id']}</li>
                                  <li class="list-group-item">Brand: ${mobile[key]['brand']}</li>
                                  <li class="list-group-item">color: ${mobile[key]['color']}</li>
                                  <li class="list-group-item">price: ${mobile[key]['price']}</li>
                             </ul>`
                $('#json-data-card').append(htmlTemplate);
            }
            // document.querySelector('#json-data-card').innerHTML=html;
            // alert(Object.keys(data).length);
        }
    }
});

$(document).on('click','#json-btn',function(){
    $.ajax({
        type:'get',
        url:'./data/mobile.json',
        success:function(response){

            for(let key in response){
                for(let key1 in response[key]){
                    htmlTemplate=`<p>ID: ${response[key][key1]['id']}</p
                                  <p>Brand: ${response[key][key1]['brand']}</p>
                                  <p>color: ${response[key][key1]['color']}</p>
                                  <p>price: ${response[key][key1]['Price']}</p>
                                 `
                    // $('#json-data-card').append(htmlTemplate);
                }
            }
            // console.log(response);
        },
        error:function(error){
            console.log(error);
        }
    });
});

//api button

let apiButton=document.getElementById('api-btn');

apiButton.addEventListener('click',function () {

    let xhr=new XMLHttpRequest();

    xhr.open('get','https://jsonplaceholder.typicode.com/users', true);

    xhr.send();

    xhr.onload=()=>{
        if (xhr.status===200){
            let data= xhr.responseText;
            let users=JSON.parse(data);
            console.log(data);
            displayApiUsers(users);
        }
    }
})

$(document).on('click','#api-btn',function () {
    $.ajax({
        type:'get',
        url:'https://jsonplaceholder.typicode.com/users',
        success:function(response){
            // console.log(response);
        },
        error:function(err){
            console.log(err);
        }
    })
})

//users

let displayApiUsers=(users)=>{
    let htmlTemplate='';
    for (let user of users){
        htmlTemplate+=`<input type="button" class="btn btn btn-primary mt-3" value="${user.id}" name="submitBtn" id="submitBtn-${user.id}">
                        <ul class="list-group mt-3">
                            <li class="list-group-item">ID: ${user.id}</li>
                            <li class="list-group-item">Name: ${user.name}</li>
                            <li class="list-group-item">User name: ${user.username}</li>
                            <li class="list-group-item">Email: ${user.email}</li>
                            <li class="list-group-item">Phone: ${user.phone}</li>
                            <li class="list-group-item">City: ${user.address.city}</li>
                            <li class="list-group-item">Website: ${user.website}</li>
                            <li class="list-group-item">Company: ${user.company.name}</li>
                        </ul>`
        }
    document.getElementById('api-data-card').innerHTML=htmlTemplate;
}

