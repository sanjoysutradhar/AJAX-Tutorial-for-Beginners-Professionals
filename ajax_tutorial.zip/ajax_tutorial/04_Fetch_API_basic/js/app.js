// Text button
// let textButton =document.querySelector('#text-btn');
let textButton =document.getElementById('text-btn');
textButton.addEventListener('click',function(){
   fetchTextData();
});

let fetchTextData=()=>{
    fetch('../data/message.txt').then((response)=>{
      if(response.status !==200){
          console.log(`something went wrong!:${response.status}`);
          return;
      }
      else{
          // console.log(response.text());
          response.text().then((data)=>{
              // console.log(data);
              let htmlTempate=`<h3>${data}</h3>`;
              document.getElementById('text-data-card').innerHTML=htmlTempate;
          })
      }
    });
}

// json button

// let jsonButton=document.getElementById('json-btn');
$(document).on('click','#json-btn', function(){
    // alert();
   fetchJsonData();
});

let fetchJsonData=()=>{
    fetch('../data/mobile.json').then((response)=>{
        if(response.status !==200){
            console.log(`something went wrong!:${response.status}`);
            return;
        }
        response.json().then((data)=>{
            // console.log(data);
            // let mobile=JSON.parse(data);
            let htmlTemplate='';
            for(let key in data){
                htmlTemplate +=`<ul class="list-group mt-3">
                                  <li class="list-group-item">ID: ${data[key]['id']}</li>
                                  <li class="list-group-item">Brand: ${data[key]['brand']}</li>
                                  <li class="list-group-item">color: ${data[key]['color']}</li>
                                  <li class="list-group-item">price: ${data[key]['price']}</li>
                             </ul>`
                // $('#json-data-card').append(htmlTemplate);
            }
            document.getElementById('json-data-card').innerHTML=htmlTemplate;
            // $('#json-data-card').append(htmlTemplate);
        });
    })
}


// Api button

$(document).on('click','#api-btn', function(){
    // alert();
    fetchApiData();
});

let fetchApiData=()=>{
    fetch('https://jsonplaceholder.typicode.com/users').then((response)=>{
        if(response.status !==200){
            console.log(`something went wrong!:${response.status}`);
            return;
        }
        // response.text().then((data)=>{
        // let users= JSON.parse(data)
        response.json().then((users)=>{
            let htmlTemplate='';
            for (let user of users){
                htmlTemplate+=`<input type="button" class="btn btn btn-primary mt-3" value="${user.id}" name="submitBtn" id="submitBtn-${user.id}">
                        <ul class="list-group mt-3">
                            <li class="list-group-item">ID: ${user.id}</li>
                            <li class="list-group-item">Name: ${user.name}</li>
                            <li class="list-group-item">User name: ${user.username}</li>
                            <li class="list-group-item">Email: ${user.email}</li>
                            <li class="list-group-item">Phone: ${user.phone}</li>
                            <li class="list-group-item">City: ${user.address.city}</li>
                            <li class="list-group-item">Website: ${user.website}</li>
                            <li class="list-group-item">Company: ${user.company.name}</li>
                        </ul>`
            }
            document.getElementById('api-data-card').innerHTML=htmlTemplate;
        });
    })
}
